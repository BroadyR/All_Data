
/**
 * Broady Rivet
 * The purpose of this code is to list a given numbewr of planes in their
 * numerical order and display their destination and days of travel.
 * 9/11/2019
 */
// basic knowledge needed to even begin let alone complete this program was taught by a friend who also assisted with the entire creation 
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.util.Scanner;
public class Plane
{
   //Instance Variables
   private int PlaneNum;
   private String Destination;
   private int DayOfTravel;
   
   //setter
   public Plane(){
        this.PlaneNum = 0;
        this.Destination = null;
        this.DayOfTravel = 0;
   }
   
   //constructor
   public Plane(int PlaneNum, String Destination, int DayOfTravel){
        this.PlaneNum = PlaneNum;
        this.Destination = Destination;
        this.DayOfTravel = DayOfTravel;
   }
   
   //methods for each variable
   public void setPlaneNum(int PlaneNum){this.PlaneNum = PlaneNum;}
   public int getPlaneNum(){return this.PlaneNum;}
   public void setDestination(String Destination){this.Destination = Destination;}
   public String getDestination(){return this.Destination;}
   public void setDayOfTravel(int DayOfTravel){this.DayOfTravel = DayOfTravel;}
   public int getDayOfTravel(){return this.DayOfTravel;}
   public String getDayOfTravelAsString(){
        String day = "";
        switch(this.DayOfTravel) {
            //number to days of week
           case 1:
                day = "Sunday";
                break;
           case 2:
                day = "Monday";
                break;
           case 3:
                day = "Tuesday";
                break;
           case 4:
                day = "Wednesday";
                break;
           case 5:
                day = "Thursday";
                break;
           case 6:
                day = "Friday";
                break;
           case 7:
                day = "Saturday";
                break;
        }
        return day;
   }
   
   //Bubble sort method used to organize given list
   public static void BubbleSort(Plane[] planeArray){
        for (int i = 0; i < planeArray.length-1; i++) {
           for (int j = 0; j < planeArray.length-i-1; j++) {
                if (planeArray[j].getPlaneNum() > planeArray[j+1].getPlaneNum()) {
                    Plane planeSwap = planeArray[j];
                    planeArray[j] = planeArray[j+1];
                    planeArray[j+1] = planeSwap;
                }
           }
       }
   }
   
   //Binary search method used to find target in sorted list
   public static void BinarySearch(Plane[] planeArray, int planeNum){
       int first = 0;
       int last = planeArray.length-1;
       int mid = (first + last)/2;
       System.out.println();
       while(first <= last) {
           if (planeArray[mid].getPlaneNum() < planeNum) {
               first = mid + 1;               
           }
           else if (planeArray[mid].getPlaneNum() == planeNum) {
                System.out.println(planeArray[mid].getPlaneNum()+" "+planeArray[mid].getDestination()+" "+planeArray[mid].getDayOfTravelAsString()); 
                break;
           }
           else{
                last = mid - 1;
           }
           mid = (first + last)/2;
       }
       if (first > last) {
            System.out.println("not here");
       }
   }
   
   //main method for program's user interface
   public static void main(String[] args)throws IOException{
       // I received assistance on this section for the reading of a file by a professor
       Plane planeArray[] = new Plane[28];
       int planeCount = 0;
              
       FileReader fr = new FileReader("Planes.txt");
       BufferedReader br = new BufferedReader(fr);
       
       String textLine = br.readLine();       
       while (!((textLine = br.readLine()).equals("")))  {
           String[] lineArray = textLine.split(",");
           Plane p = new Plane();
                p.setPlaneNum(Integer.parseInt(lineArray[0].trim())); 
                p.setDestination(lineArray[1].trim()); 
                p.setDayOfTravel(Integer.parseInt(lineArray[2].trim())); 
                //lineArray[3].trim() == "yes", 
                //Integer.parseInt(lineArray[4].trim()), 
                //Integer.parseInt(lineArray[5].trim()));
           
           planeArray[planeCount++] = p;
       }
       BubbleSort(planeArray); 
       String userInput = "";
       while (true) {
          System.out.println();
          System.out.println("(L)ist Planes");
          System.out.println("(F)ind Plane");
          System.out.println("(E)nd Program");
          System.out.print("Enter choice: ");
          Scanner input = new Scanner(System.in);
          userInput = input.nextLine();
          System.out.println();
         if (userInput.equals("L") || userInput.equals("l")) {
               PrintPlaneList(planeArray);
          }  
         if (userInput.equals("F") || userInput.equals("f")) {
               System.out.print("What plane number would you like to search for? ");
               BinarySearch(planeArray, input.nextInt());
         }
         if (userInput.equals("E") || userInput.equals("e")) {
               System.out.println("End Program");
               break;
         }
       }
   }

   //final output of target
   public static void PrintPlaneList(Plane[] planeArray){
        for (int i = 0; i < planeArray.length; i++) {
            System.out.println(planeArray[i].getPlaneNum()+" "+planeArray[i].getDayOfTravelAsString()+" 0"); 
        }
   }
}




