/* ***************************************************
 * 
 * <Broady Rivet>
 * <9/19/19>
 *
 *****************************************************/

 // All (NullPointExceptions e) line were given to me and explained by a classmate

public class List<Type>
{
    // We don't actually have to set a max size with linked lists
    // But it is a good idea.
    // Just picture an infinite loop adding to the list! :O
    // Yes, you may change this when you do your word count program.
    public static final int MAX_SIZE = 100;

    private Node<Type> head;
    private Node<Type> tail;
    private Node<Type> curr;
    private int num_items;

    // constructor
    // remember that an empty list has a "size" of -1 and its "position" is at -1
    public List()
    {
        head = null;
        tail = null;
        curr = null;
        num_items = 0;
    }

    // copy constructor
    // clones the list l and sets the last element as the current
    // (notice we're not just copying the whole list at once?)
    public List(List<Type> l)
    {
        Node<Type> n = new Node();
        n.setLink(l.head);

        this.head = this.tail = this.curr = null;
        this.num_items = 0;

        while (n.getLink() != null)
        {
            this.InsertAfter(n.getLink().getData());
            n.setLink(n.getLink().getLink());
        }
    }

    // navigates to the beginning of the list
    public void First()
    {
        try
        {
            curr.setLink(head.getLink());
        }
        catch(NullPointerException e)
        {
            ;
        }
    }

    // navigates to the end of the list
    // the end of the list is at the last valid item in the list
    public void Last()
    {
        try
        {
            curr.setLink(tail.getLink());
        }
        catch(NullPointerException e)
        {
            ;
        }
    }

    // navigates to the specified element (0-index)
    // this should not be possible for an empty list
    // this should not be possible for invalid positions
    public void SetPos(int pos)
    {
        if(!IsEmpty() && pos < GetSize())
        {
            First();
            for (int i = 0; i <= pos; i++)
            {
                this.Next();
            }
        }
    }

    // navigates to the previous element
    // this should not be possible for an empty list
    // there should be no wrap-around
    public void Prev()
    {
        if(curr.getLink() == head.getLink()){
            return;
        }
        // initialize a new node, temp
        Node<Type> temp = this.curr.getLink();
        
        // set curr to head
        this.curr.setLink(this.head.getLink());
        
        // initialize a variable for the while loop
        boolean found = false;
        
        try {
            while (!found) 
            {
                // in case the data at curr equals to the temp
                if (this.curr.getLink().equals(temp)) 
                {
                    // set found to true
                    found = true;
                } else 
                
                {
                    // in the other case, keeps running the variable along the list
                    this.Next();
                }
            }
        } catch (NullPointerException e) {
            ;
        }
    }

    
    // navigates to the next element
    // this should not be possible for an empty list
    // there should be no wrap-around
    public void Next()
    {
        if(curr.getLink() != null)
        {
            curr.setLink(curr.getLink().getLink());
        }
    }

    // returns the location of the current element (or -1)
    public int GetPos()
    {
        if((head == null) || (head.getLink() == null))
       {
            return -1;
       }
        Node temp = new Node();
        temp.setLink(head.getLink());
       for (int i = 0; i <= num_items; i++)
        {
         if (this.curr.getLink() == temp.getLink())
         {
             return i;
            }
         else
         { //temp should be changing, not curr
             temp.setLink(temp.getLink().getLink());
            }
        }
        return -1;
    }

    // returns the value of the current element (or -1)
    // type = null not (-1)
    // The try and catch of the nullpointexception line was given to me by a classmate
    public Type GetValue()
    {
        try {
            return this.curr.getLink().getData();
        } catch (NullPointerException e) {
            return null;
        }
    }

    // returns the size of the list
    // size does not imply capacity
    public int GetSize()
    {
        return num_items;
    }

    // inserts an item before the current element
    // the new element becomes the current
    // this should not be possible for a full list
    public void InsertBefore(Type data)
    {
        if (GetSize() != MAX_SIZE)
        {
                try
            {
                    if (head == null) {this.InsertAfter(data);}
                    else if(curr.getLink() == head.getLink()){
                        Node t = new Node();
                        t.setData(data);
                        t.setLink(this.head.getLink());
                        this.head.setLink(t);
                    }
                    else{
                        Prev();
                        this.InsertAfter(data);
                    }       
            }
            catch(NullPointerException e)
            {
                ;
            }
        }
    }

    // inserts an item after the current element
    // the new element becomes the current
    // this should not be possible for a full list
    //increase num_items +1
    public void InsertAfter(Type data)
    {
        if(head == null) //start of list
        {
            head = new Node();
            tail = new Node();
            curr = new Node();
            Node m = new Node();
            m.setData(data);
            head.setLink(m);
            tail.setLink(m);
            curr.setLink(m);
            num_items ++;
        }
        else
        {
            Node b = new Node();
            b.setData(data);
            //b.setLink(curr.getLink());
            this.curr.getLink().setLink(b);
            this.curr.setLink(b);
            if (this.curr.getLink().getLink() == null) {
                this.tail.setLink(b);
            }
            num_items ++;
        }
    }

    // removes the current element 
    // this should not be possible for an empty list
    public void Remove()
    {
        if(head.getLink() != null)
        {
         Node temp = this.curr.getLink();
         int position = GetPos();
         this.curr.setLink(this.head.getLink());
         if(curr.getLink() == temp)
         {
             curr.setLink(curr.getLink().getLink());
         }
         else
         {
             if(curr.getLink() != null)
             {
                 SetPos(position);
             }
          }
        }
    }

    // replaces the value of the current element with the specified value
    // this should not be possible for an empty list
    public void Replace(Type data)
    {
        if(this.head.getLink() != null)
        {
            this.curr.getLink().setData(data);
        }
        }

    // returns if the list is empty
    public boolean IsEmpty()
    {
        if (num_items == 0)
        {
            return true;
        }
        return false;
    }

    // returns if the list is full
    public boolean IsFull()
    {
        if (num_items == MAX_SIZE)
        {
            return true;
        }
        return false;
    }

    // returns if two lists are equal (by value)
    public boolean Equals(List<Type> l)
    {
        Node<Type> x = this.head.getLink();
        Node<Type> h = l.head.getLink();
        boolean same = true;
        if (this.GetSize() == l.GetSize()) {
            for (int i = 0; i < GetSize(); i++) {
                if (x.getData() != h.getData()) {
                    same = false;
                    break;
                }
                x = x.getLink();
                h = h.getLink();
            }
        } else {
            same = false;
        }
        return same;
    }

    // returns the concatenation of two lists
    // l should not be modified
    // l should be concatenated to the end of *this
    // the returned list should not exceed MAX_SIZE elements
    // the last element of the new list is the current
    //this method was assisted by classmate(entire method)
    public List<Type> Add(List<Type> l)
    {
        List<Type> values = new List<Type>(this);
        Node<Type> add = null;
        Node<Type> add2 = null;
        
        if (values.head != null) 
        {
            add = values.tail.getLink();
        }
        else 
        {
            values.head = new Node<Type>();
            values.tail = new Node<Type>();
        }
        
        if (l.head != null) 
        {
            add2 = l.head.getLink();
        }

        if (this.GetSize() <= MAX_SIZE) 
        {
            if (add == null && add2 != null) 
            {
                values.head.setLink(add2);
            } else if (add != null && add2 == null) 
            {
                ;
            }
            
            else 
            {
                add.setLink(add2);
            }
        } 
        values.GetSize();
        values.Last();
        values.Next();
        return values;
    }

    // returns a string representation of the entire list (e.g., 1 2 3 4 5)
    // the string "NULL" should be returned for an empty list
    public String toString()
    {
        String output = " ";
        int location = this.GetPos();
        boolean next = true;
       
        try {
            if (this.head == null || this.head.getLink() == null) {
                return "NULL";
            }
            First();
            do {
                output += this.curr.getLink().getData() + "";
                next = (this.curr.getLink() != null);
                this.Next();
              
            } while (next);
            
        } catch (NullPointerException e) {
            System.out.println(" a null pointer exception has happened.");
        }
        this.SetPos(location);
        return output;
    }
}