
/**
 * Broady Rivet
 * The purpose of this code is to list a given numbewr of planes in their
 * numerical order and display their destination and days of travel.
 * 9/18/2019
 */
// basic knowledge needed to even begin let alone complete this program was taught by a friend who also assisted with the entire creation 
import java.io.FileReader;
import java.io.IOException;
import java.io.BufferedReader;
import java.util.Scanner;
class Passenger // this class is perfect - lj
{
    private String Name;
    private String FoodPreference;
    //setter
    public Passenger(){
        this.Name = "empty";
        this.FoodPreference = "none";
    }
    //constructor
    public Passenger(String Name, String FoodPreference){
        this.Name = Name;
        this.FoodPreference = FoodPreference;
    }
    public void setName(String Name){this.Name = Name;}
    public String getName(){return this.Name;}
    public void setFoodPreference(String FoodPreference){this.FoodPreference = FoodPreference;}
    public String getFoodPreference(){return this.FoodPreference;}
}
public class Plane
{
   //Instance Variables
   private int PlaneNum;
   private String Destination;
   private int DayOfTravel;
   private boolean HasMeal;
   private int NumOnPlane;
   private int MaxSeats;
   private int Rows;
   private int seatsPerRow;
   private Passenger[][] Bookings;
   
   //setter
   public Plane(){
       this.PlaneNum = 0;
       this.Destination = null;
       this.DayOfTravel = 0;
       this.HasMeal = true;
       this.NumOnPlane = 0;
       this.MaxSeats = 0;
       this.Rows = 0;
       this.seatsPerRow = 0;
   }
   
   //constructor - I fixed this for you - you just needed to pass it more info (lj)
   public Plane(int PlaneNum, String Destination, int DayOfTravel, boolean HasMeal, int Rows, int seatsPerRow){
        this.PlaneNum = PlaneNum;
        this.Destination = Destination;
        this.DayOfTravel = DayOfTravel;
        this.HasMeal = HasMeal;
        this.NumOnPlane = 0; //nobody here yet
        this.MaxSeats = Rows * seatsPerRow; //MaxSeats;
        this.Rows = Rows;
        this.seatsPerRow = seatsPerRow;
        this.Bookings = new Passenger[Rows][seatsPerRow];
   }
   
   //methods for each variable
   public void setPlaneNum(int PlaneNum){this.PlaneNum = PlaneNum;}
   public int getPlaneNum(){return this.PlaneNum;}
   public void setDestination(String Destination){this.Destination = Destination;}
   public String getDestination(){return this.Destination;}
   public void setDayOfTravel(int DayOfTravel){this.DayOfTravel = DayOfTravel;}
   public int getDayOfTravel(){return this.DayOfTravel;}
   public void setHasMeal(boolean HasMeal){this.HasMeal = HasMeal;}
   public boolean getHasMeal(){return this.HasMeal;}
   public void setNumOnPlane(int NumOnPlane){this.NumOnPlane = NumOnPlane;}
   public int getNumOnPlane(){return this.NumOnPlane;}
   public void setMaxSeats(int MaxSeats){this.MaxSeats = MaxSeats;}
   public int getMaxSeats(){return this.MaxSeats;}
   public void setRows(int Rows){this.Rows = Rows;}
   public int getRows(){return this.Rows;}
   public void setseatsPerRow(int seatsPerRow){this.seatsPerRow = seatsPerRow;}
   public int getseatsPerRow(){return this.seatsPerRow;}
   public String getDayOfTravelAsString(){
        String day = "";
        switch(this.DayOfTravel) {
            //number to days of week
           case 1:
                day = "Sunday";
                break;
           case 2:
                day = "Monday";
                break;
           case 3:
                day = "Tuesday";
                break;
           case 4:
                day = "Wednesday";
                break;
           case 5:
                day = "Thursday";
                break;
           case 6:
                day = "Friday";
                break;
           case 7:
                day = "Saturday";
                break;
        }
        return day;
   }
   
   public void setPassenger (String name, String food, int row, int seat)
   { //needs 2 lines of code
       // 1. create a new Passenger object using name and food
       Passenger f1 = new Passenger(name, food);
       // 2. put it in your 2D array @ [row-1][seat-1]
       Bookings[row-1][seat-1] = f1;
    }
   
   public Passenger getPassenger (int row, int seat) // I wrote this for you - lj
   {
       return Bookings[row-1][seat-1];
    }
    
   public int howManyOnPlane() //lj
    { //in this method, you're going to count how many seats are taken
        // You know a seat is taken if it does not = null
        int numOnPlane = 0;
        //1) loop through the rows
        for(int i = 0; i < this.Rows; i++){
        // 2) loop through the seats (nested loop)
        for(int j = 0; j < this.seatsPerRow; j++){
            //3) if the bookings at that row and seat != null, increment numOnPlane
            if(Bookings[i][j] != null){
                numOnPlane++;
            }
            //close the loops
        }
    }
    return numOnPlane;
    }
    
   public boolean isPlaneFull() //lj
    { //this method will return false if ANY of the booking positions = null, otherwise return true
        // so like the above method, loop through the bookings array
        for(int i = 0; i < this.Rows; i++){
            for(int j = 0; j < this.seatsPerRow; j++){
                if(Bookings[i][j] == null){
                    return false;
                }
            }
        }
        // if you get to a position that = null, return false;
        //this goes after the loop finishes
        return true;
    }
    //I tried find passenger for about three hours after our discussion on dscord 
    // and i just couldn't do it.
    
   //Bubble sort method used to organize given list
   public static void BubbleSort(Plane[] planeArray){
        for (int i = 0; i < planeArray.length-1; i++) {
           for (int j = 0; j < planeArray.length-i-1; j++) {
                if (planeArray[j].getPlaneNum() > planeArray[j+1].getPlaneNum()) {
                    Plane planeSwap = planeArray[j];
                    planeArray[j] = planeArray[j+1];
                    planeArray[j+1] = planeSwap;
                }
           }
       }
   }
   
   //Binary search method used to find target in sorted list
   //Changed so it would return the index of the plane - lj
   public static int BinarySearch(Plane[] planeArray, int planeNum){
       int first = 0;
       int last = planeArray.length-1;
       int mid = (first + last)/2;
       System.out.println();
       while(first <= last) {
           if (planeArray[mid].getPlaneNum() < planeNum) {
               first = mid + 1;               
           }
           else if (planeArray[mid].getPlaneNum() == planeNum) {
                System.out.println(planeArray[mid].getPlaneNum()+" "+planeArray[mid].getDestination()+" "+planeArray[mid].getDayOfTravelAsString()); 
                return mid;
           }
           else{
                last = mid - 1;
           }
           mid = (first + last)/2;
       }
       if (first > last) {
            System.out.println("not here");
            
       }
       return -1;
   }
   
   //main method for program's user interface
   public static void main(String[] args)throws IOException{
       // I received assistance on this section for the reading of a file by a professor
       Plane planeArray[] = new Plane[28];
       int planeCount = 0;
              
       FileReader fr = new FileReader("Planes.txt");
       FileReader fr1 = new FileReader("bookings.csv");
       BufferedReader br = new BufferedReader(fr);
       BufferedReader br1 = new BufferedReader(fr1);
       
       String textLine = br.readLine();       
       while (!((textLine = br.readLine()).equals("")))  {
           String[] lineArray = textLine.split(", ");
            Plane p = new Plane(Integer.parseInt(lineArray[0]),
            lineArray[1], Integer.parseInt(lineArray[2]), (lineArray[3] == "yes"),
            Integer.parseInt(lineArray[4]), Integer.parseInt(lineArray[5]));
                // p.setPlaneNum(Integer.parseInt(lineArray[0])); 
                // p.setDestination(lineArray[1].trim()); 
                // p.setDayOfTravel(Integer.parseInt(lineArray[2])); 
                // p.setHasMeal(lineArray[3] == "yes");
                
                // p.setNumOnPlane(Integer.parseInt(lineArray[4]));

                // p.setMaxSeats(Integer.parseInt(lineArray[5]));
                
           
           planeArray[planeCount++] = p;
       }
       BubbleSort(planeArray); 
       
       //I could not get this section to work i tried to switch to scanner and just got more errors that confused me more.
       //here, you'll read in the bookings file and put people on their planes - lj
       textLine = br1.readLine();       
       while (!((textLine = br1.readLine()).equals("")))  {
           String[] lineArray = textLine.split(",");
           // use the first element in lineArray and your binary search to find the correct plane - save the index in an int variable
           int i = BinarySearch(planeArray, Integer.parseInt(lineArray[0]));
           // put the passenger on the plane
           planeArray[i].setPassenger(lineArray[1], lineArray[2], Integer.parseInt(lineArray[3]), Integer.parseInt(lineArray[4]));
        }
       
       
       String userInput = "";
       while (true) {
          System.out.println();
          System.out.println("(L)ist Planes");
          System.out.println("(F)ind Plane");
          System.out.println("(E)nd Program");
          System.out.println("(I)s plane full?"); //lj
          System.out.println("(H)ow many on plane?"); //lj
          System.out.print("Enter choice: ");
          Scanner input = new Scanner(System.in);
          userInput = input.nextLine();
          System.out.println();
         if (userInput.equals("L") || userInput.equals("l")) {
               PrintPlaneList(planeArray);
          }  
         if (userInput.equals("F") || userInput.equals("f")) {
               System.out.print("What plane number would you like to search for? ");
               BinarySearch(planeArray, input.nextInt());
         }
         if (userInput.equals("I") || userInput.equals("i")) { //lj
               System.out.print("What plane number would you like to check if full? ");
               int i = BinarySearch(planeArray, input.nextInt());
               if (planeArray[i].isPlaneFull()) System.out.println("Plane is full.");
               else System.out.println("Plane has seats available.");
         }
         if (userInput.equals("H") || userInput.equals("h")) { //lj
               System.out.print("What plane number would you like to check? ");
               int i = BinarySearch(planeArray, input.nextInt());
               int howMany = planeArray[i].howManyOnPlane();
               System.out.println("There are " + howMany + " people on this plane.");
         }
         if (userInput.equals("E") || userInput.equals("e")) {
               System.out.println("End Program");
               break;
         }
       }
   }

   //final output of target
   public static void PrintPlaneList(Plane[] planeArray){
      for (int i = 0; i < planeArray.length; i++) {
            System.out.println(planeArray[i].getPlaneNum()+" "+planeArray[i].getDayOfTravelAsString()+" 0"); 
        }
    }
}




