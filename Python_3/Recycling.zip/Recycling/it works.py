## https://gist.github.com/mohamedelfiky/46554323d7acb889554ab8262ceb44e3
## https://algotree.org/algorithms/single_source_shortest_path/dijkstras_shortest_path_python/
import queue
import time
import sys
import os
from collections import defaultdict


class Node(object):
    def __init__(self, value):
        self.value = value
        self.edges = []
        self.visited = False

class Edge(object):
    def __init__(self, value, node_from, node_to):
        self.value = value
        self.node_from = node_from
        self.node_to = node_to

class Grapher(object):
    def __init__(self, nodes=None, edges=None):
        self.nodes = nodes or []
        self.edges = edges or []
        self._node_map = {}

    def insert_node(self, new_node_val):
        new_node = Node(new_node_val)
        self.nodes.append(new_node)
        self._node_map[new_node_val] = new_node
        return new_node

    def add_edge(self, node_from_val, node_to_val, new_edge_val):
        nodes = {node_from_val: None, node_to_val: None}
        for node in self.nodes:
            if node.value in nodes:
                nodes[node.value] = node
                if all(nodes.values()):
                    break
        for node_val in nodes:
            nodes[node_val] = nodes[node_val] or self.insert_node(node_val)
        node_from = nodes[node_from_val]
        node_to = nodes[node_to_val]
        new_edge = Edge(new_edge_val, node_from, node_to)
        node_from.edges.append(new_edge)
        node_to.edges.append(new_edge)
        self.edges.append(new_edge)

    def get_edge_list(self):
        return [(e.value, e.node_from.value, e.node_to.value)
                for e in self.edges]

    def find_max_index(self):
        max_index = -1
        if len(self.nodes):
            for node in self.nodes:
                if node.value > max_index:
                    max_index = node.value
        return max_index

    def find_node(self, node_number):
        return self._node_map.get(node_number)

    def _clear_visited(self):
        for node in self.nodes:
            node.visited = False

    def dfs_helper(self, start_node):
        ret_list = [start_node.value]
        start_node.visited = True
        for edge in start_node.edges:
            if edge.node_to.visited == False:
                ret_list += self.dfs_helper(edge.node_to)
        return ret_list

    def dfs(self, start_node_num):
        self._clear_visited()
        start_node = self.find_node(start_node_num)
        return self.dfs_helper(start_node)

    def bfs(self, start_node_num):

        node = self.find_node(start_node_num)
        self._clear_visited()
        q = queue.Queue()
        ret_list = [node.value]
        node.visited = True
        while len(ret_list) < len(self.nodes):
            for edge in node.edges:
                if edge.node_to.visited == False:
                    edge.node_to.visited = True
                    ret_list.append(edge.node_to.value)
                    q.put(edge.node_to)
            node = q.get()

        return ret_list

##########################################################
##########################################################
## could not for the life of us implement dijirkstra using previously made classes
## Dijirkstra code starts here
###########################################################
###########################################################
class Node_Distance :

    def __init__(self, name, dist) :
        self.name = name
        self.dist = dist

class Graph:

    def __init__(self, node_count) :
        # Store the adjacency list as a dictionary
        # The default dictionary would create an empty list as a default (value) 
        # for the nonexistent keys.
        self.adjlist = defaultdict(list)
        self.node_count = node_count

    def Add_Into_Adjlist(self, src, node_dist) :
        self.adjlist[src].append(node_dist)

    def Dijkstras_Shortest_Path(self, source) :

        # Initialize the distance of all the nodes from the source node to infinity
        distance = [999999999999] * self.node_count
        # Distance of source node to itself is 0
        distance[source] = 0

        # Create a dictionary of { node, distance_from_source }
        dict_node_length = {source: 0}

        while dict_node_length :

            # Get the key for the smallest value in the dictionary
            # i.e Get the node with the shortest distance from the source
            current_source_node = min(dict_node_length, key = lambda k: dict_node_length[k])
            del dict_node_length[current_source_node]

            for node_dist in self.adjlist[current_source_node] :
                adjnode = node_dist.name
                length_to_adjnode = node_dist.dist

                # Edge relaxation
                if distance[adjnode] > distance[current_source_node] + length_to_adjnode :
                    distance[adjnode] = distance[current_source_node] + length_to_adjnode
                    dict_node_length[adjnode] = distance[adjnode]
        i = 1
        while (i < self.node_count) :
            print("Source Node ("+str(source)+")  -> Destination Node(" + str(i) + ")  : " + str(distance[i]))
            i += 1

g = Grapher()
f = Graph(49)

g.add_edge("1", "10", 1)
g.add_edge("1", "23", 4)
g.add_edge("10", "1", 1)
g.add_edge("23", "1", 4)
g.add_edge("23", "9", 7)
g.add_edge("23", "24", 5)
g.add_edge("24", "23", 5)
g.add_edge("9", "23", 7)
g.add_edge("24", "2", 8)
g.add_edge("24", "8", 6)
g.add_edge("8", "24", 6)
g.add_edge("2", "24", 8)
g.add_edge("2", "7", 3)
g.add_edge("2", "25", 9)
g.add_edge("7", "2", 3)
g.add_edge("2", "2", 9)
g.add_edge("25", "6", 10)
g.add_edge("25", "26", 1)
g.add_edge("6", "25", 10)
g.add_edge("26", "25", 1)
g.add_edge("26", "5", 2)
g.add_edge("26", "3", 11)
g.add_edge("5", "26", 2)
g.add_edge("3", "26", 11)
g.add_edge("3", "27", 5)
g.add_edge("3", "4", 12)
g.add_edge("4", "3", 12)
g.add_edge("27", "3", 5)
g.add_edge("27", "28", 3)
g.add_edge("4", "28", 13)
g.add_edge("28", "27", 3)
g.add_edge("28", "4", 13)
g.add_edge("5", "6", 1)
g.add_edge("6", "5", 1)
g.add_edge("7", "6", 4)
g.add_edge("6", "7", 4)
g.add_edge("7", "8", 6)
g.add_edge("8", "7", 6)
g.add_edge("9", "8", 10)
g.add_edge("8", "9", 10)
g.add_edge("9", "10", 1)
g.add_edge("10", "9", 1)
g.add_edge("10", "11", 5)
g.add_edge("11", "10", 5)
g.add_edge("5", "30", 7)
g.add_edge("30", "5", 7)
g.add_edge("30", "12", 8)
g.add_edge("12", "30", 8)
g.add_edge("30", "11", 9)
g.add_edge("28", "29", 2)
g.add_edge("29", "28", 2)
g.add_edge("29", "13", 4)
g.add_edge("13", "29", 4)
g.add_edge("12", "13", 3)
g.add_edge("13", "12", 3)
g.add_edge("29", "31", 7)
g.add_edge("31", "29", 7)
g.add_edge("31", "32", 1)
g.add_edge("32", "31", 1)
g.add_edge("32", "33", 3)
g.add_edge("33", "32", 3)
g.add_edge("33", "40", 6)
g.add_edge("40", "33", 6)
g.add_edge("40", "22", 12)
g.add_edge("22", "40", 12)
g.add_edge("40", "41", 4)
g.add_edge("41", "40", 4)
g.add_edge("41", "42", 9)
g.add_edge("42", "41", 9)
g.add_edge("42", "43", 10)
g.add_edge("43", "42", 10)
g.add_edge("43", "21", 13)
g.add_edge("21", "43", 13)
g.add_edge("42", "20", 7)
g.add_edge("20", "42", 7)
g.add_edge("20", "44", 11)
g.add_edge("44", "20", 11)
g.add_edge("44", "15", 14)
g.add_edge("15", "45", 16)
g.add_edge("45", "46", 1)
g.add_edge("32", "34", 2)
g.add_edge("34", "35", 2)
g.add_edge("35", "48", 8)
g.add_edge("48", "31", 6)
g.add_edge("48", "14", 5)
g.add_edge("14", "48", 5)
g.add_edge("11", "47", 12)
g.add_edge("47", "11", 12)
g.add_edge("47", "44", 9)
g.add_edge("44", "47", 9)
g.add_edge("46", "41", 3)
g.add_edge("41", "46", 3)
g.add_edge("34", "36", 8)
g.add_edge("36", "34", 8)
g.add_edge("36", "37", 1)
g.add_edge("37", "38", 9)
g.add_edge("38", "39", 10)
g.add_edge("39", "40", 13)
g.add_edge("40", "39", 13)
g.add_edge("39", "38", 10)
g.add_edge("38", "37", 9)
g.add_edge("37", "36", 1)
g.add_edge("46", "38", 4)
g.add_edge("38", "46", 4)
g.add_edge("39", "19", 5)
g.add_edge("19", "39", 5)
g.add_edge("38", "18", 12)
g.add_edge("18", "38", 12)
g.add_edge("37", "16", 15)
g.add_edge("16", "37", 15)
g.add_edge("36", "17", 1)

f.Add_Into_Adjlist(1, Node_Distance(10, 1))
f.Add_Into_Adjlist(1, Node_Distance(23, 4))
f.Add_Into_Adjlist(10, Node_Distance(1, 1))
f.Add_Into_Adjlist(23, Node_Distance(1, 4))
f.Add_Into_Adjlist(23, Node_Distance(9, 7))
f.Add_Into_Adjlist(23, Node_Distance(24, 5))
f.Add_Into_Adjlist(24, Node_Distance(23, 5))
f.Add_Into_Adjlist(9, Node_Distance(23, 7))
f.Add_Into_Adjlist(24, Node_Distance(2, 8))
f.Add_Into_Adjlist(24, Node_Distance(8, 6))
f.Add_Into_Adjlist(8, Node_Distance(24, 6))
f.Add_Into_Adjlist(2, Node_Distance(24, 8))
f.Add_Into_Adjlist(2, Node_Distance(7, 3))
f.Add_Into_Adjlist(2, Node_Distance(25, 9))
f.Add_Into_Adjlist(7, Node_Distance(2, 3))
f.Add_Into_Adjlist(2, Node_Distance(2, 9))
f.Add_Into_Adjlist(25, Node_Distance(6, 10))
f.Add_Into_Adjlist(25, Node_Distance(26, 1))
f.Add_Into_Adjlist(6, Node_Distance(25, 10))
f.Add_Into_Adjlist(26, Node_Distance(25, 1))
f.Add_Into_Adjlist(26, Node_Distance(5, 2))
f.Add_Into_Adjlist(26, Node_Distance(3, 11))
f.Add_Into_Adjlist(5, Node_Distance(26, 2))
f.Add_Into_Adjlist(3, Node_Distance(26, 11))
f.Add_Into_Adjlist(3, Node_Distance(27, 5))
f.Add_Into_Adjlist(3, Node_Distance(4, 12))
f.Add_Into_Adjlist(4, Node_Distance(3, 12))
f.Add_Into_Adjlist(27, Node_Distance(3, 5))
f.Add_Into_Adjlist(27, Node_Distance(28, 3))
f.Add_Into_Adjlist(4, Node_Distance(28, 13))
f.Add_Into_Adjlist(28, Node_Distance(27, 3))
f.Add_Into_Adjlist(28, Node_Distance(4, 13))
f.Add_Into_Adjlist(5, Node_Distance(6, 1))
f.Add_Into_Adjlist(6, Node_Distance(5, 1))
f.Add_Into_Adjlist(7, Node_Distance(6, 4))
f.Add_Into_Adjlist(6, Node_Distance(7, 4))
f.Add_Into_Adjlist(7, Node_Distance(8, 6))
f.Add_Into_Adjlist(8, Node_Distance(7, 6))
f.Add_Into_Adjlist(9, Node_Distance(8, 10))
f.Add_Into_Adjlist(8, Node_Distance(9, 10))
f.Add_Into_Adjlist(9, Node_Distance(10, 1))
f.Add_Into_Adjlist(10, Node_Distance(9, 1))
f.Add_Into_Adjlist(10, Node_Distance(11, 5))
f.Add_Into_Adjlist(11, Node_Distance(10, 5))
f.Add_Into_Adjlist(5, Node_Distance(30, 7))
f.Add_Into_Adjlist(30, Node_Distance(5, 7))
f.Add_Into_Adjlist(30, Node_Distance(12, 8))
f.Add_Into_Adjlist(12, Node_Distance(30, 8))
f.Add_Into_Adjlist(30, Node_Distance(11, 9))
f.Add_Into_Adjlist(28, Node_Distance(29, 2))
f.Add_Into_Adjlist(29, Node_Distance(28, 2))
f.Add_Into_Adjlist(29, Node_Distance(13, 4))
f.Add_Into_Adjlist(13, Node_Distance(29, 4))
f.Add_Into_Adjlist(12, Node_Distance(13, 3))
f.Add_Into_Adjlist(13, Node_Distance(12, 3))
f.Add_Into_Adjlist(29, Node_Distance(31, 7))
f.Add_Into_Adjlist(31, Node_Distance(29, 7))
f.Add_Into_Adjlist(31, Node_Distance(32, 1))
f.Add_Into_Adjlist(32, Node_Distance(31, 1))
f.Add_Into_Adjlist(32, Node_Distance(33, 3))
f.Add_Into_Adjlist(33, Node_Distance(32, 3))
f.Add_Into_Adjlist(33, Node_Distance(40, 6))
f.Add_Into_Adjlist(40, Node_Distance(33, 6))
f.Add_Into_Adjlist(40, Node_Distance(22, 12))
f.Add_Into_Adjlist(22, Node_Distance(40, 12))
f.Add_Into_Adjlist(40, Node_Distance(41, 4))
f.Add_Into_Adjlist(41, Node_Distance(40, 4))
f.Add_Into_Adjlist(41, Node_Distance(42, 9))
f.Add_Into_Adjlist(42, Node_Distance(41, 9))
f.Add_Into_Adjlist(42, Node_Distance(43, 10))
f.Add_Into_Adjlist(43, Node_Distance(42, 10))
f.Add_Into_Adjlist(43, Node_Distance(21, 13))
f.Add_Into_Adjlist(21, Node_Distance(43, 13))
f.Add_Into_Adjlist(42, Node_Distance(20, 7))
f.Add_Into_Adjlist(20, Node_Distance(42, 7))
f.Add_Into_Adjlist(20, Node_Distance(44, 11))
f.Add_Into_Adjlist(44, Node_Distance(20, 11))
f.Add_Into_Adjlist(44, Node_Distance(15, 14))
f.Add_Into_Adjlist(15, Node_Distance(45, 16))
f.Add_Into_Adjlist(45, Node_Distance(46, 1))
f.Add_Into_Adjlist(32, Node_Distance(34, 2))
f.Add_Into_Adjlist(34, Node_Distance(35, 2))
f.Add_Into_Adjlist(35, Node_Distance(48, 8))
f.Add_Into_Adjlist(48, Node_Distance(31, 6))
f.Add_Into_Adjlist(48, Node_Distance(14, 5))
f.Add_Into_Adjlist(14, Node_Distance(48, 5))
f.Add_Into_Adjlist(11, Node_Distance(47, 12))
f.Add_Into_Adjlist(47, Node_Distance(11, 12))
f.Add_Into_Adjlist(47, Node_Distance(44, 9))
f.Add_Into_Adjlist(44, Node_Distance(47, 9))
f.Add_Into_Adjlist(46, Node_Distance(41, 3))
f.Add_Into_Adjlist(41, Node_Distance(46, 3))
f.Add_Into_Adjlist(34, Node_Distance(36, 8))
f.Add_Into_Adjlist(36, Node_Distance(34, 8))
f.Add_Into_Adjlist(36, Node_Distance(37, 1))
f.Add_Into_Adjlist(37, Node_Distance(38, 9))
f.Add_Into_Adjlist(38, Node_Distance(39, 10))
f.Add_Into_Adjlist(39, Node_Distance(40, 13))
f.Add_Into_Adjlist(40, Node_Distance(39, 13))
f.Add_Into_Adjlist(39, Node_Distance(38, 10))
f.Add_Into_Adjlist(38, Node_Distance(37, 9))
f.Add_Into_Adjlist(37, Node_Distance(36, 1))
f.Add_Into_Adjlist(46, Node_Distance(38, 4))
f.Add_Into_Adjlist(38, Node_Distance(46, 4))
f.Add_Into_Adjlist(39, Node_Distance(19, 5))
f.Add_Into_Adjlist(19, Node_Distance(39, 5))
f.Add_Into_Adjlist(38, Node_Distance(18, 12))
f.Add_Into_Adjlist(18, Node_Distance(38, 12))
f.Add_Into_Adjlist(37, Node_Distance(16, 15))
f.Add_Into_Adjlist(16, Node_Distance(37, 15))
f.Add_Into_Adjlist(36, Node_Distance(17, 1))


output = open("output.txt", "w+")


tic1 = time.perf_counter()
print ("\nDepth First Search")
print(g.dfs("2"))
toc1 = time.perf_counter()
dfs = toc1-tic1
output.write("DFS Took: " + str(toc1-tic1) + " seconds")

tic2 = time.perf_counter()
print ("\nBreadth First Search")
print(g.bfs("2"))
toc2 = time.perf_counter()
bfs = toc2-tic2
output.write("\nBFS Took: " + str(toc2 - tic2) + " seconds")

tic3 = time.perf_counter()
print ("\nDijkstra")
f.Dijkstras_Shortest_Path(2)
toc3 = time.perf_counter()
dij = toc3-tic3
output.write("\nDijkstra Took: " + str(toc3 - tic3) + " seconds")

if(dfs < bfs):
    if(dfs < dij):
        output.write("\nDFS is the fastest")
    else:
        output.write("\nDijkstras is the fastest")
elif(bfs < dfs):
    if(bfs < dij):
        output.write("\nBFS is the fastest")
    else:
        output.write("\nDijkstras and black is the fastest")

output.close()





