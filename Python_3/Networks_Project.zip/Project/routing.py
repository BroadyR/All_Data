##################################################
##Name:Broady Rivet                             ##
##Project: CSC 450                              ##
##################################################
##I was assisted in this project by grad student who helped me throught the tough struggles.
import sys

##replacement so you dont have to call in the csv library.
def read_csv(file:str)->list:
    csv = open(file,'r')
    result = []
    for i in csv.readlines():
        ##goes through and appends new found results in the cvs file
        ##and deletes white spaces created when moving lines
        result.append(i.rstrip('\n').split(','))
    return result

##if the current string is equal to the source then itll return the value
## otherwise increment curr and recursively go throught the function again.
def recur(P:dict, source:str, curr:str):
    if curr == source:
        return source
    return recur(P, source, P[curr])+curr
    
##creating the tree which will be the shortest
def shortest_tree(P:dict, source:str):
    tree = {}
    for i in P:
        tree[i] = recur(P,source, i)
    return tree

##I had assistance on the node class from a higher level student
##Came from pseudocode in previous notes
class Node:
    all_nodes = {}
    ##init just setting values and variable to use in the class
    def __init__(self, name, nodes):
        self.name = name
        self.Dx = self.Cx = {i:cost[name][i] for i in nodes}
        INF = {i:9999 for i in nodes}
        self.Dv = {i:INF for i in nodes}
        self.Dv[self.name] = self.Dx
        self.adjacent = [i for i in self.Dx if i != name and self.Cx[i] != 9999]

        Node.all_nodes.update({name:self})
        self.update_Dv()

    def bellman_ford(self,curr):
        for node in self.Dx:
            ##if current values added together are larger than the Dx node
            ## then replace the Dx node and update the Dv
            if((self.Cx[curr]+self.Dv[curr][node]) < self.Dx[node]):
                self.Dx[node] = (self.Cx[curr] + self.Dv[curr][node])
                self.update_Dv()
    ##Function to update the Dv called in the bellman ford algorithm
    def update_Dv(self):
        for node in self.adjacent:
            if node in Node.all_nodes:
                current_node = Node.all_nodes[node]
                self.Dv[current_node.name] = current_node.Dx
                self.bellman_ford(current_node.name)

                current_node.Dv[self.name] = self.Dx
                current_node.bellman_ford(self.name)

    def __str__(self):
        return ', '.join([str(self.Dx[i]) for i in self.Dx])

def distance_vector(headers:list):
    return {i:Node(i, headers) for i in headers}

##Start Dijkstras
##also came from pseudocode from notes
def dijkstras(nodes:list, source:str):
    D = {}
    P = {}
    N = list(source)

    for curr_node in nodes:
        if(cost[curr_node][source]!=9999):
            D[curr_node] = cost[curr_node][source]
            P[curr_node] = source
        else:
            D[curr_node] = 9999

    curr_node = source

    ##this is what will make the algorithm repeat
    while len(N) < len(nodes):
        Dw = {h:t for h,t in D.items() if h not in N}
        w = min(Dw, key=Dw.get)
        N.append(w)
        
        ex_nodes = [i for i in nodes if i not in N]
        for curr_node in ex_nodes:
            nD = min(D[curr_node], (D[w]+cost[w][curr_node]))
            if(nD != D[curr_node]):
                D[curr_node] = nD
                P[curr_node] = w
    P = shortest_tree(P, source)
    
    return D,P

##ask for the source node you will be starting from to go to your destination,
## read your file and begin discovering the path of the tree
if __name__ == '__main__':
    ##Final statments for printing everything in the correct format
    file = sys.argv[1]
    source = input("Please provide a source node: ")
    data = read_csv(file)
    data[0].remove("")
    headers = data[0]
    cost = {i[0]:{headers[a]:int(i[1:][a]) for a in range(len(i[1:]))} for i in data[1:]}
    D,P = dijkstras(data[0], source)
    tree = ', '.join(P.values())
    costs = ', '.join([f"{h}:{t}" for h,t in D.items()])
    print(f"Shortest path tree for node {source}:\n {tree}")
    print(f"Costs of the least-cost paths for node  {source}:\n {costs}")
    ##run through the found vectors and display them, the route/ distances
    ##then continue to the next in line.
    result = distance_vector(headers)
    for i in result:
        print(f"Distance vector for node {i}: {result[i]}")
