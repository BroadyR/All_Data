################################
##Name: Broady Rivet          ##
##Date: 04/23/21              ##
##Program: Stuck In Trees     ##
################################
#after many obstacles and errors and breakdowns I requested help from a python using
#classmate and Jack Foil provided me with the framework and a lot of guidance and helped me
#me through this entire thing so i could get it done by the weekend. THANK YOU JACK!!

import time
import sys
import os


#creates the output file
#creating a new one replaces the previously made one on each run
output = open("output.txt", "w+")


#reads text file specified in the same location as .py file
f = open("SciFiLiBooks.txt", "r")
text = (f.read())


# Counts the number of lines. Source: https://www.geeksforgeeks.org/count-number-of-lines-in-a-text-file-in-python/
colist = text.split("\n")

num_lines = 0
for i in colist:
    if i:
        num_lines +=1


# Compare the two words to see which one would go alphabetically order (this function will be used for most trees)
def compare(word1, word2):
    word1 = word1.replace(" ", "")
    word2 = word2.replace(" ", "")
    lesser = False
    
    min_num= min(len(word1), len(word2))

    #using the ord() function allows us to return intergers to represent the uni code characters of the specified position in the gathered word
    ###uncommon function but very useful, save in notes.
    for i in range(min_num):
        if(ord(word1[i]) > ord(word2[i])):
            lesser = False
            break
            
        elif(ord(word1[i]) < ord(word2[i])):
            lesser = True
            break
    #returns the lesser value of the two words
    return lesser



#the class node
class node:
    def __init__(self, value=None):
        self.value = value
        self.left_child = None
        self.right_child = None
        self.parent = None
        self.depth = 1
    


############################################################################################
################################ Binary search Tree ########################################
############################################################################################

#This class is a straight copy from my "tutor" so i have the base class to work with for the rest of the tress to inherit from        
class binary_search_tree:
    def __init__(self):
        self.root= None

    #inserts the nodes into the tree
    def insert(self, value):
        if(self.root == None):
            self.root = node(value)
        else:
            self._insert(value, self.root)

    # this is the main function for inserting nodes into the tree 
    def _insert(self,value, cur_node):
        
        if(compare(value, cur_node.value) == True):
            if(cur_node.left_child == None):
                cur_node.left_child = node(value)
                cur_node.left_child.parent = cur_node #sets the parent
            else:
                self._insert(value, cur_node.left_child)
        elif(compare(value, cur_node.value) == False):
            if(cur_node.right_child == None):
                cur_node.right_child = node(value)
                cur_node.right_child.parent=cur_node #sets the parent
                
            else:
                self._insert(value, cur_node.right_child)
        else:
            print("already in the tree")

    #prints the tree (makes it easier to see if code is working)
    def print_tree(self):
        if(self.root != None):
            self._print_tree(self.root)

    def _print_tree(self, cur_node):
        if(cur_node!=None):
            self._print_tree(cur_node.left_child)
            print(str(cur_node.value))
            self._print_tree(cur_node.right_child)


    #searches for the value in the tree 
    def search(self, value):
        if(self.root !=None):
            return self._search(value, self.root)
        else:
            print("Not in Library")
            
    #the main search function
    def _search(self, value, cur_node):
        if(value == cur_node.value):
            print("Found in Library: " + str(cur_node.value))
        elif(compare(value, cur_node.value) == True and cur_node.left_child != None):
            self._search(value, cur_node.left_child)
        elif(compare(value, cur_node.value) == False and cur_node.right_child != None):
            self._search(value, cur_node.right_child)
        else:
            print("Not in Library")


    # finds the node and value associated with it (helps with deletion fucntion)
    def find(self,value):
        if(self.root!=None):
                return self._find(value,self.root)
        else:
                return None
                
    # finds the value of the node (this function mainly helps with delete function)
    def _find(self,value,cur_node):
        if(value==cur_node.value):
                return cur_node
        elif(compare(value, cur_node.value) == True and cur_node.left_child!=None):
                return self._find(value,cur_node.left_child)
        elif(compare(value, cur_node.value) == False and cur_node.right_child!=None):
                return self._find(value,cur_node.right_child)
    

    # deltes the value of the node
    def delete_value(self,value):
        return self.delete_node(self.find(value))

    def delete_node(self,node):
        # Protect against deleting a node not found in the tree
        if node==None or self.find(node.value)==None:
            print("Node to be deleted not found in the tree!")
            return None 

        # returns the node with min value in tree rooted at input node
        def min_value_node(n):
            current=n
            while current.left_child!=None:
                    current=current.left_child
            return current

        # returns the number of children for the specified node
        def num_children(n):
            num_children=0
            if n.left_child!=None: num_children+=1
            if n.right_child!=None: num_children+=1
            return num_children

        # get the parent of the node to be deleted
        node_parent=node.parent

        # get the number of children of the node to be deleted
        node_children=num_children(node)

        # break operation into different cases based on the
        # structure of the tree & node to be deleted

        # CASE 1 (node has no children)
        if node_children==0:

            # Added this if statement post-video, previously if you 
            # deleted the root node it would delete entire tree.
            if node_parent!=None:
                    # remove reference to the node from the parent
                if node_parent.left_child==node:
                    node_parent.left_child=None
                else:
                    node_parent.right_child=None
            else:
                self.root=None

        # CASE 2 (node has a single child)
        if node_children==1:

            # get the single child node
            if node.left_child!=None:
                child=node.left_child
            else:
                child=node.right_child

            # Added this if statement post-video, previously if you 
            # deleted the root node it would delete entire tree.
            if node_parent!=None:
                    # replace the node to be deleted with its child
                if node_parent.left_child==node:
                    node_parent.left_child=child
                else:
                    node_parent.right_child=child
            else:
                self.root=child

            # correct the parent pointer in node
            child.parent=node_parent

        # CASE 3 (node has two children)
        if node_children==2:
            # get the inorder successor of the deleted node
            successor=min_value_node(node.right_child)

            # copy the inorder successor's value to the node formerly
            # holding the value we wished to delete
            node.value=successor.value
            self.delete_node(successor)




############################################################################################
############################################### AVL Tree ###################################
############################################################################################

#AVL Tree pulled from https://www.freecodecamp.org/news/avl-tree/
#I improved and/or simplified anything I could find and adjusted commets to be logical and note worth when looking back for later projects
class AVL_tree:
    def __init__(self):
        self.root= None

    def insert(self, value):
        if(self.root == None):
            self.root = node(value)
        else:
            self._insert(value, self.root)


    def _insert(self,value, cur_node):
        if(compare(value, cur_node.value) == True):
            if(cur_node.left_child == None):
                cur_node.left_child = node(value)
                cur_node.left_child.parent = cur_node
                self._inspect_insertion(cur_node.left_child)
            else:
                self._insert(value, cur_node.left_child)
        elif(compare(value, cur_node.value) == False):
            if(cur_node.right_child == None):
                cur_node.right_child = node(value)
                cur_node.right_child.parent=cur_node 
                self._inspect_insertion(cur_node.right_child) 
            else:
                self._insert(value, cur_node.right_child)
        else:
            print("already in the tree")

        
    def print_tree(self):
        if(self.root != None):
            self._print_tree(self.root)

    def _print_tree(self, cur_node):
        if(cur_node!=None):
            self._print_tree(cur_node.left_child)
            print(str(cur_node.value) + " == " + str(cur_node.depth))
            self._print_tree(cur_node.right_child)


    def search(self, value):
        binary_search_tree.search(self, value)


    def _search(self, value, cur_node):
        binary_search_tree._search(self, value, cur_node)
        

    def find(self,value):
        return binary_search_tree.find(self, value)
        
                
    def _find(self,value,cur_node):
        return binary_search_tree._find(self, value, cur_node)
    
    #gets the depth of the current node
    def depth(self):
        return binary_search_tree._depth(self)


    def _depth(self,cur_node,cur_depth):
        return binary_search_tree._depth(self, cur_node, cur_depth)


    def delete_value(self,value):
        return self.delete_node(binary_search_tree.find(self, value))

    def delete_node(self,node):
        if node==None or self.find(node.value)==None:
            print("Node to be deleted not found in the tree!")
            return None 

        def min_value_node(n):
            current=n
            while current.left_child!=None:
                    current=current.left_child
            return current

        def num_children(n):
            num_children=0
            if n.left_child!=None: num_children+=1
            if n.right_child!=None: num_children+=1
            return num_children

        node_parent=node.parent
        node_children=num_children(node)


        # CASE 1 - two child
        if node_children==2:
            successor=min_value_node(node.right_child)
            node.value=successor.value
            self.delete_node(successor)
            return

        # CASE 2 - single child, adjust
        if node_children==1:

            if node.left_child!=None:
                child=node.left_child
            else:
                child=node.right_child

            if node_parent!=None:
                if node_parent.left_child==node:
                    node_parent.left_child=child
                else:
                    node_parent.right_child=child
            else:
                self.root=child

            child.parent=node_parent 

        # CASE 3 - no child just delete node
        if node_children==0:
            if node_parent!=None:
                if node_parent.left_child==node:
                    node_parent.left_child=None
                else:
                    node_parent.right_child=None
            else:
                self.root=None

        if(node_parent != None):
            node_parent.depth=1+max(self.get_depth(node_parent.left_child),self.get_depth(node_parent.right_child))
            self._inspect_deletion(node_parent)

    #Checks for unbalanced nodes while inserting the rebalances
    def _inspect_insertion(self, cur_node, path = []):
        if(cur_node.parent == None):
            return
        path =[cur_node]+path

        #find the depth of both the left and right side of the tree
        left_depth =self.get_depth(cur_node.parent.left_child) 
        right_depth=self.get_depth(cur_node.parent.right_child)

        #the abs function was being used but that finds absolute values which doesn't
        #effect anything here
        if((left_depth - right_depth)>1):
            path = [cur_node.parent]+path
            self._rebalance_node(path[0],path[1],path[2])
            return

        new_depth = 1+cur_node.depth

        #both the above and below if statements are checking for unbalances nodes and rebalancing them
        if(new_depth>cur_node.parent.depth):
            cur_node.parent.depth = new_depth

        self._inspect_insertion(cur_node.parent, path)

    #above and below functions are nearly identical but have slight changes for insertions and
        #deletions
    #Check for unblanced nodes while deleting and rebalances
    def _inspect_deletion(self,cur_node):
        if (cur_node==None):
            return

        left_depth =self.get_depth(cur_node.left_child) 
        right_depth=self.get_depth(cur_node.right_child)

        if((left_depth-right_depth)>1): 
            y=self.taller_child(cur_node)
            x=self.taller_child(y)
            self._rebalance_node(cur_node,y,x)  

        self._inspect_deletion(cur_node.parent)

    #all rebalncing rotation cases 
    def _rebalance_node(self,z,y,x):
        if(y== z.left_child and x== y.left_child):
            self._right_rotate(z)
        elif(y== z.left_child and x== y.right_child):
            self._left_rotate(y)
            self._right_rotate(z)
        elif(y== z.right_child and x== y.right_child):
            self._left_rotate(z)
        elif(y== z.right_child and x== y.left_child):
            self._right_rotate(y)
            self._left_rotate(z)
        #This raised exception below feels unnecessary with current assignment, I dont understand why its in but i
        #will leave it incase a problem arises
        ##else:
          ##  raise Exception('_rebalance_node: z,y,x node configuration not recognized!')

    #right rotation 
    def _right_rotate(self,z):
        sub_root=z.parent 
        y= z.left_child
        t3= y.right_child
        y.right_child= z
        z.parent= y
        z.left_child= t3
        
        if(t3!=None):
            t3.parent=z
            
        y.parent=sub_root
        
        if(y.parent==None):
            self.root=y
        else:
            if(y.parent.left_child==z):
                y.parent.left_child=y
            else:
                y.parent.right_child=y
                
        z.depth= 1+ max(self.get_depth(z.left_child),
                        self.get_depth(z.right_child))
        y.depth= 1+ max(self.get_depth(y.left_child),
                        self.get_depth(y.right_child))
    
        
    #left rotation 
    def _left_rotate(self,z):
        sub_root= z.parent 
        y= z.right_child
        t2= y.left_child
        y.left_child= z
        z.parent= y
        z.right_child= t2
        if (t2!=None):
            t2.parent=z
            
        y.parent=sub_root
        
        if(y.parent==None): 
            self.root=y
        else:
            if (y.parent.left_child==z):
                y.parent.left_child=y
            else:
                y.parent.right_child=y
        z.depth=1+max(self.get_depth(z.left_child),
                      self.get_depth(z.right_child))
        y.depth=1+max(self.get_depth(y.left_child),
                      self.get_depth(y.right_child))

    # gets the depth of the child 
    def get_depth(self,cur_node):
        if(cur_node == None):
            return 0
        return cur_node.depth

    # finds the tallest child out of parent    
    def taller_child(self,cur_node):
        left=self.get_depth(cur_node.left_child)
        right=self.get_depth(cur_node.right_child)
        return cur_node.left_child if left>=right else cur_node.right_child



        
########################################################################################################Red-black Tree
#Creating a seperate node class for Red black tree and labeling it Node instead of node
#helps keep organized and allows us to pull multiple nodes at once
#1 == RED
# 0 == Black

#Pulled from https://github.com/Bibeknam/algorithmtutorprograms/blob/master/data-structures/red-black-trees/red_black_tree.py
#with additions of inheritance
class Node():
    def __init__(self, value = None):
        self.value = value
        self.left_child = None
        self.right_child = None
        self.parent = None
        self.color = 1
    
class RedBlackTree():
    def __init__(self):
        self.TNULL = Node(0)
        self.TNULL.color = 0
        self.TNULL.left = None
        self.TNULL.right = None
        self.root = self.TNULL


    # Search the tree for a specific tree
    def search_tree_helper(self, node, key):
        if node == None or key == node.value:
            if node == None:
                print("Cannot be found in library")
            else:
                print("Found in Library: " + str(node.value))
            return node
        #helps narrow down where the node might be by seeing if it is grater than or less than 
        if(compare(key, str(node.value)) == True):
            return self.search_tree_helper(node.left, key)
        return self.search_tree_helper(node.right, key)

    # when a node is deleated it balances and adjusts its color along with it 
    def delete_fix(self, x): 
        while x != self.root and x.color == 0:
            if x == x.parent.left:
                s = x.parent.right
                if s.color == 1:
                    s.color = 0
                    x.parent.color = 1
                    self.left_rotate(x.parent)
                    s = x.parent.right

                if s.left.color == 0 and s.right.color == 0:
                    s.color = 1
                    x = x.parent
                else:
                    if s.right.color == 0:
                        s.left.color = 0
                        s.color = 1
                        self.right_rotate(s)
                        s = x.parent.right

                    s.color = x.parent.color
                    x.parent.color = 0
                    s.right.color = 0
                    self.left_rotate(x.parent)
                    x = self.root
            else:
                s = x.parent.left
                if s.color == 1:
                    s.color = 0
                    x.parent.color = 1
                    self.right_rotate(x.parent)
                    s = x.parent.left

                if s.right.color == 0 and s.right.color == 0:
                    s.color = 1
                    x = x.parent
                else:
                    if s.left.color == 0:
                        s.right.color = 0
                        s.color = 1
                        self.left_rotate(s)
                        s = x.parent.left

                    s.color = x.parent.color
                    x.parent.color = 0
                    s.left.color = 0
                    self.right_rotate(x.parent)
                    x = self.root
        x.color = 0

    #transplant is that node that needs to be deleted and is replaced with another node
    def __rb_transplant(self, u, v):
        if u.parent == None:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent

    # deletes the node and adjust the color 
    def delete_node_helper(self, node, key):
        z = self.TNULL
        while node != self.TNULL:
            if node.item == key:
                z = node

            if (compare(node.item, key) == True):
                node = node.right
            else:
                node = node.left

        if z == self.TNULL:
            print("Cannot find key in the tree")
            return

        y = z
        y_original_color = y.color
        if z.left == self.TNULL:
            x = z.right
            self.__rb_transplant(z, z.right)
        elif (z.right == self.TNULL):
            x = z.left
            self.__rb_transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self.__rb_transplant(y, y.right)
                y.right = z.right
                y.right.parent = y

            self.__rb_transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color
        if y_original_color == 0:
            self.delete_fix(x)

    # Balance the tree after insertion
    def fix_insert(self, k):
        while k.parent.color == 1:
            if k.parent == k.parent.parent.right:
                u = k.parent.parent.left
                if u.color == 1:
                    u.color = 0
                    k.parent.color = 0
                    k.parent.parent.color = 1
                    k = k.parent.parent
                else:
                    if k == k.parent.left:
                        k = k.parent
                        self.right_rotate(k)
                    k.parent.color = 0
                    k.parent.parent.color = 1
                    self.left_rotate(k.parent.parent)
            else:
                u = k.parent.parent.right

                if u.color == 1:
                    u.color = 0
                    k.parent.color = 0
                    k.parent.parent.color = 1
                    k = k.parent.parent
                else:
                    if k == k.parent.right:
                        k = k.parent
                        self.left_rotate(k)
                    k.parent.color = 0
                    k.parent.parent.color = 1
                    self.right_rotate(k.parent.parent)
            if k == self.root:
                break
        self.root.color = 0

    # searches for the specific node the user is trying to find 
    def searchTree(self, k):
        return self.search_tree_helper(self.root, k)

    #helps find the minimum node in the tree
    def minimum(self, node):
        while node.left != self.TNULL:
            node = node.left
        return node

    # rotaates the node to the left 
    def left_rotate(self, x):
        y = x.right
        x.right = y.left
        if y.left != self.TNULL:
            y.left.parent = x

        y.parent = x.parent
        if x.parent == None:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y
        y.left = x
        x.parent = y

    # rotstes the node to the right 
    def right_rotate(self, x):
        y = x.left
        x.left = y.right
        if y.right != self.TNULL:
            y.right.parent = x

        y.parent = x.parent
        if x.parent == None:
            self.root = y
        elif x == x.parent.right:
            x.parent.right = y
        else:
            x.parent.left = y
        y.right = x
        x.parent = y

    # inserts the nodes and adjustrs the color 
    def insert(self, key):
        #creates the node and adds its intilizers 
        node = Node(key)
        node.parent = None
        node.item = key
        node.left = self.TNULL
        node.right = self.TNULL
        node.color = 1
        y = None
        x = self.root

        #firgure out where to insert into the tree
        while x != self.TNULL:
            y = x
            if(compare(node.item, x.item) == True):
                x = x.left
            else:
                x = x.right

        node.parent = y
        if y == None:
            self.root = node
        elif(compare(node.item, y.item) == True):
            y.left = node
        else:
            y.right = node

    #changes the color depedning if it has a parent or not 
        if node.parent == None:
            node.color = 0
            return

        if node.parent.parent == None:
            return

        self.fix_insert(node)


    #allows it to get the root
    def get_root(self):
        return self.root 
    # helps delete the node
    def delete_node(self, item):
        self.delete_node_helper(self.root, item)




########################################################
#################### Main Section ######################
########################################################

#jack gave me this section to improve my timing!
#this was much more effiecent than how I was using the time.time() at the beggining and
#ending of each function and calling the times all together at the end

#starts the first timer
start = time.perf_counter()

#run the binary search tree function
tree_bin = binary_search_tree()
for j in range(num_lines):
    tree_bin.insert(colist[j])


#Search for book that is not in the library
tree_bin.search("Harry Potter")


#remove a book (that is in the library)
tree_bin.delete_value("Fahrenheit 451")

#stop the first timer
stop = time.perf_counter()

#print the output file and time
output.write("Binary Tree Took: " + str(stop - start) + " seconds")
bs = stop - start


################################################
################################################

#starts the second timer
tic_2 = time.perf_counter()

#Create the AVL tree
tree_avl = AVL_tree()
for k in range(num_lines):
    tree_avl.insert(colist[k])

        
#Search for book that is not in the library
tree_avl.search("The Yellow Wallpaper")


#remove a book (that is in the library)
tree_avl.delete_value("Princess Bride")

toc_2 = time.perf_counter()

avl = toc_2 - tic_2
output.write("\nAVL Tree Took: " + str(toc_2-tic_2) + " seconds")


###############################################
###############################################

#starts the third timer
tic_3 = time.perf_counter()

#Create the Red Black Tree
bst = RedBlackTree()

for k in range(num_lines):
    bst.insert(colist[k])

#Search for book that is not in the library
bst.searchTree("Grendel")
    
#remove a book (that is in the library)
bst.delete_node("Stardust")

toc_3 = time.perf_counter()
rb = toc_3-tic_3

output.write("\nRed Black Tree Took: " + str(toc_3-tic_3) + " seconds")




#Prints the race results 
if(bs < avl):
    if(bs < rb):
        output.write("\nBinary Search is the fastest")
    else:
        output.write("\nRed and black is the fastest")
elif(avl < bs):
    if(avl < rb):
        output.write("\nAVL is the fastest")
    else:
        output.write("\nRed and black is the fastest")


#close and save ouput text file
output.close()
